/**
 * Demo — Timer Manager + Async Queue
 * Запустіть: node demo.js
 */

const { createTimerManager } = require('./src/timerManager');
const { createQueue } = require('./src/asyncQueue');

function delay(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

// ─────────────────────────────────────────────
//  DEMO 1: Timer Manager
// ─────────────────────────────────────────────
async function demoTimerManager() {
  console.log('═══════════════════════════════════════');
  console.log('       DEMO: Timer Manager');
  console.log('═══════════════════════════════════════\n');

  const tm = createTimerManager();

  // setTimeout
  console.log('▶ Реєструємо setTimeout (100ms)…');
  tm.setTimeout(() => console.log('  ⏰ setTimeout спрацював!'), 100);

  // setInterval — кожні 150мс
  console.log('▶ Реєструємо setInterval (150ms)…');
  let count = 0;
  const intervalId = tm.setInterval(() => {
    count++;
    console.log(`  🔁 interval tick #${count}`);
  }, 150);

  // Показуємо активні таймери
  await delay(50);
  const active = tm.getActive();
  console.log(`\n▶ getActive() — ${active.length} активних таймерів:`);
  active.forEach((t) => console.log(`  id=${t.id} type=${t.type} remaining≈${Math.round(t.remaining)}ms`));

  // Пауза
  await delay(60);
  console.log('\n▶ pause() — пауза всіх таймерів');
  tm.pause();
  await delay(300); // пауза 300мс — нічого не має спрацювати

  // Відновлення
  console.log('▶ resume() — відновлення');
  tm.resume();
  await delay(500);

  // Зупинка interval
  tm.clear(intervalId);
  console.log(`\n▶ clear(intervalId) — interval зупинено після ${count} тіків`);
  console.log('▶ getActive():', tm.getActive());
}

// ─────────────────────────────────────────────
//  DEMO 2: Async Queue
// ─────────────────────────────────────────────
async function demoAsyncQueue() {
  console.log('\n═══════════════════════════════════════');
  console.log('       DEMO: Async Queue');
  console.log('═══════════════════════════════════════\n');

  // Черга з паралелізмом 2
  const q = createQueue(2);

  q.onDrain(() => {
    console.log('\n✅ onDrain: черга порожня!\n');
    console.log('📊 Фінальна статистика:', q.getStats());
  });

  // Додаємо 5 завдань
  const jobs = ['Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon'];

  console.log('▶ Додаємо 5 завдань (concurrency=2)…\n');

  const promises = jobs.map((name, i) =>
    q.add(async () => {
      console.log(`  ▸ [START] ${name}`);
      await delay(80 + i * 20);
      console.log(`  ◂ [DONE ] ${name}`);
      return name;
    })
  );

  // Показуємо статистику одразу
  await delay(10);
  console.log('▶ getStats() одразу:', q.getStats());

  // Пауза після 150мс
  await delay(140);
  console.log('\n▶ pause() — ставимо на паузу');
  q.pause();
  console.log('  (isPaused:', q.isPaused(), ')');
  await delay(200);

  // Відновлення
  console.log('\n▶ resume()');
  q.resume();

  await Promise.all(promises);
}

// ─────────────────────────────────────────────
//  RUN
// ─────────────────────────────────────────────
(async () => {
  await demoTimerManager();
  await demoAsyncQueue();
})();
