/**
 * Async Queue
 * Реалізує асинхронну чергу із обмеженим паралелізмом через замикання.
 */

/**
 * @param {number} concurrency - максимальна кількість паралельних завдань (за замовчуванням 1)
 */
function createQueue(concurrency = 1) {
  // Приватний стан через замикання
  let queue = [];          // { fn, resolve, reject }
  let activeCount = 0;
  let paused = false;
  let drainCallbacks = [];

  // Статистика
  let stats = {
    processed: 0,   // завершено
    queued: 0,      // зараз у черзі
    active: 0,      // зараз виконується
  };

  /**
   * Запускає наступне завдання з черги, якщо є слот
   */
  function tryNext() {
    if (paused) return;
    if (activeCount >= concurrency) return;
    if (queue.length === 0) {
      // Черга порожня — викликаємо drain-колбеки
      if (activeCount === 0 && drainCallbacks.length > 0) {
        const cbs = drainCallbacks.slice();
        drainCallbacks = [];
        cbs.forEach((cb) => cb());
      }
      return;
    }

    const { fn, resolve, reject } = queue.shift();
    stats.queued--;
    activeCount++;
    stats.active = activeCount;

    Promise.resolve()
      .then(() => fn())
      .then((result) => {
        stats.processed++;
        resolve(result);
      })
      .catch((err) => {
        reject(err);
      })
      .finally(() => {
        activeCount--;
        stats.active = activeCount;
        tryNext();
      });
  }

  /**
   * Додає асинхронне завдання до черги
   * @param {Function} asyncFn - функція, що повертає Promise
   * @returns {Promise} - резолвиться коли завдання завершене
   */
  function add(asyncFn) {
    return new Promise((resolve, reject) => {
      queue.push({ fn: asyncFn, resolve, reject });
      stats.queued++;
      tryNext();
    });
  }

  /**
   * Призупиняє обробку нових завдань
   * (вже запущені завдання продовжують виконуватись)
   */
  function pause() {
    paused = true;
  }

  /**
   * Відновлює обробку завдань
   */
  function resume() {
    if (!paused) return;
    paused = false;
    // Запускаємо стільки завдань, скільки є вільних слотів
    const slots = concurrency - activeCount;
    for (let i = 0; i < slots; i++) {
      tryNext();
    }
  }

  /**
   * Реєструє колбек, який буде викликано коли черга стане порожньою
   * @param {Function} fn
   */
  function onDrain(fn) {
    drainCallbacks.push(fn);
  }

  /**
   * Повертає поточну статистику
   * @returns {{ processed: number, queued: number, active: number }}
   */
  function getStats() {
    return { ...stats };
  }

  /**
   * Повертає розмір черги (ще не запущені завдання)
   */
  function size() {
    return queue.length;
  }

  /**
   * Перевіряє чи черга на паузі
   */
  function isPaused() {
    return paused;
  }

  return {
    add,
    pause,
    resume,
    onDrain,
    getStats,
    size,
    isPaused,
  };
}

module.exports = { createQueue };
