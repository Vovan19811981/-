/**
 * Timer Manager
 * Реалізує менеджер таймерів через замикання.
 * Підтримує setTimeout/setInterval з паузою, відновленням та автоочищенням.
 */

function createTimerManager() {
  // Приватний стан через замикання
  let timers = new Map(); // id -> { type, fn, delay, remaining, startedAt, paused, intervalId/timeoutId }
  let idCounter = 0;
  let isPaused = false;

  /**
   * Генерує унікальний ID таймера
   */
  function nextId() {
    return ++idCounter;
  }

  /**
   * Видаляє завершений таймер із Map
   */
  function cleanup(id) {
    timers.delete(id);
  }

  /**
   * setTimeout через замикання
   * @param {Function} fn - колбек
   * @param {number} delay - затримка в мс
   * @returns {number} id таймера
   */
  function setTimeout_(fn, delay) {
    const id = nextId();

    const wrappedFn = () => {
      fn();
      cleanup(id);
    };

    const nativeId = globalThis.setTimeout(wrappedFn, delay);

    timers.set(id, {
      id,
      type: 'timeout',
      fn,
      delay,
      remaining: delay,
      startedAt: Date.now(),
      paused: false,
      nativeId,
    });

    return id;
  }

  /**
   * setInterval через замикання
   * @param {Function} fn - колбек
   * @param {number} delay - інтервал в мс
   * @returns {number} id таймера
   */
  function setInterval_(fn, delay) {
    const id = nextId();

    const nativeId = globalThis.setInterval(fn, delay);

    timers.set(id, {
      id,
      type: 'interval',
      fn,
      delay,
      remaining: delay,
      startedAt: Date.now(),
      paused: false,
      nativeId,
    });

    return id;
  }

  /**
   * Очищає конкретний таймер
   * @param {number} id
   */
  function clear(id) {
    const timer = timers.get(id);
    if (!timer) return;

    if (timer.type === 'timeout') {
      globalThis.clearTimeout(timer.nativeId);
    } else {
      globalThis.clearInterval(timer.nativeId);
    }

    cleanup(id);
  }

  /**
   * Очищає всі таймери
   */
  function clearAll() {
    for (const [id] of timers) {
      clear(id);
    }
  }

  /**
   * Призупиняє всі таймери
   */
  function pause() {
    if (isPaused) return;
    isPaused = true;

    const now = Date.now();

    for (const [id, timer] of timers) {
      if (timer.paused) continue;

      if (timer.type === 'timeout') {
        globalThis.clearTimeout(timer.nativeId);
        timer.remaining = timer.remaining - (now - timer.startedAt);
        timer.paused = true;
      } else {
        globalThis.clearInterval(timer.nativeId);
        timer.paused = true;
      }
    }
  }

  /**
   * Відновлює всі таймери
   */
  function resume() {
    if (!isPaused) return;
    isPaused = false;

    for (const [id, timer] of timers) {
      if (!timer.paused) continue;

      if (timer.type === 'timeout') {
        const remaining = Math.max(0, timer.remaining);
        const nativeId = globalThis.setTimeout(() => {
          timer.fn();
          cleanup(id);
        }, remaining);
        timer.nativeId = nativeId;
        timer.startedAt = Date.now();
        timer.paused = false;
      } else {
        const nativeId = globalThis.setInterval(timer.fn, timer.delay);
        timer.nativeId = nativeId;
        timer.startedAt = Date.now();
        timer.paused = false;
      }
    }
  }

  /**
   * Повертає список активних таймерів з часом, що залишився
   * @returns {Array} масив об'єктів { id, type, remaining }
   */
  function getActive() {
    const now = Date.now();
    const result = [];

    for (const [id, timer] of timers) {
      let remaining;

      if (timer.paused) {
        remaining = timer.remaining;
      } else if (timer.type === 'timeout') {
        remaining = Math.max(0, timer.remaining - (now - timer.startedAt));
      } else {
        // Для interval — час до наступного спрацювання
        const elapsed = (now - timer.startedAt) % timer.delay;
        remaining = timer.delay - elapsed;
      }

      result.push({ id, type: timer.type, remaining });
    }

    return result;
  }

  return {
    setTimeout: setTimeout_,
    setInterval: setInterval_,
    clear,
    clearAll,
    pause,
    resume,
    getActive,
  };
}

module.exports = { createTimerManager };
