# Timer Manager + Async Queue

> Варіант 6 — реалізація менеджера таймерів та асинхронної черги через **замикання** (closures) в JavaScript.

---

## Структура проєкту

```
timer-async-queue/
├── src/
│   ├── timerManager.js   # Timer Manager
│   ├── asyncQueue.js     # Async Queue
│   └── index.js          # Публічний API
├── tests/
│   ├── timerManager.test.js
│   └── asyncQueue.test.js
├── demo.js               # Інтерактивне демо
├── package.json
└── README.md
```

---

## Запуск

```bash
# Тести
npm test

# Тільки Timer Manager
npm run test:timers

# Тільки Async Queue
npm run test:queue

# Демо
npm run demo
```

---

## Timer Manager

Менеджер таймерів, що обгортає нативні `setTimeout` / `setInterval` і додає паузу, відновлення та відстеження.

### API

```js
const { createTimerManager } = require('./src/timerManager');
const tm = createTimerManager();
```

| Метод | Опис |
|---|---|
| `tm.setTimeout(fn, delay)` | Запускає одноразовий таймер, повертає `id` |
| `tm.setInterval(fn, delay)` | Запускає повторюваний таймер, повертає `id` |
| `tm.clear(id)` | Скасовує конкретний таймер |
| `tm.clearAll()` | Скасовує всі таймери |
| `tm.pause()` | Призупиняє всі таймери (зберігає `remaining`) |
| `tm.resume()` | Відновлює всі таймери з того місця, де зупинились |
| `tm.getActive()` | Повертає масив `{ id, type, remaining }` |

### Приклад

```js
const tm = createTimerManager();

const id = tm.setTimeout(() => console.log('Done!'), 1000);

// Через 300мс — пауза
setTimeout(() => tm.pause(), 300);

// Через 600мс — відновлення (таймер ще має ~700мс)
setTimeout(() => tm.resume(), 600);

// Перегляд активних
console.log(tm.getActive());
// [{ id: 1, type: 'timeout', remaining: ~700 }]
```

---

## Async Queue

Черга з обмеженим паралелізмом. Нові завдання чекають у черзі, поки не звільниться слот.

### API

```js
const { createQueue } = require('./src/asyncQueue');
const q = createQueue(2); // concurrency = 2
```

| Метод | Опис |
|---|---|
| `q.add(asyncFn)` | Додає завдання, повертає `Promise` з результатом |
| `q.pause()` | Призупиняє запуск нових завдань (активні продовжують) |
| `q.resume()` | Відновлює обробку черги |
| `q.onDrain(fn)` | Реєструє колбек, що спрацює коли черга спустіє |
| `q.getStats()` | Повертає `{ processed, queued, active }` |
| `q.size()` | Кількість завдань у черзі (ще не запущені) |
| `q.isPaused()` | `true` якщо черга на паузі |

### Приклад

```js
const q = createQueue(2); // максимум 2 одночасних

q.onDrain(() => console.log('All done!', q.getStats()));

for (let i = 1; i <= 5; i++) {
  q.add(async () => {
    await fetch(`https://api.example.com/item/${i}`);
    console.log(`Item ${i} fetched`);
  });
}

// Пауза після старту
setTimeout(() => q.pause(), 100);
setTimeout(() => q.resume(), 500);
```

---

## Критерії виконання

| Критерій | Бали |
|---|---|
| Timer Manager (всі методи + автоочищення) | 3.5 |
| Async Queue (concurrency, pause/resume, onDrain, статистика) | 3.5 |
| Якість коду та документація | 2 |
| Demo video | 1 |
| **Разом** | **10** |
