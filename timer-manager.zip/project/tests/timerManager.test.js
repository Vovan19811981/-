/**
 * Тести для Timer Manager
 */

const { createTimerManager } = require('../src/timerManager');

// Простий тест-раннер без зовнішніх залежностей
let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`  ✅ ${message}`);
    passed++;
  } else {
    console.error(`  ❌ ${message}`);
    failed++;
  }
}

function delay(ms) {
  return new Promise((res) => globalThis.setTimeout(res, ms));
}

async function runTests() {
  console.log('\n📋 Timer Manager Tests\n');

  // --- Test 1: setTimeout виконується ---
  console.log('Test 1: setTimeout виконується');
  {
    const tm = createTimerManager();
    let called = false;
    tm.setTimeout(() => { called = true; }, 50);
    await delay(100);
    assert(called, 'setTimeout колбек викликано');
    assert(tm.getActive().length === 0, 'таймер видалено після виконання');
  }

  // --- Test 2: setInterval виконується кілька разів ---
  console.log('\nTest 2: setInterval виконується кілька разів');
  {
    const tm = createTimerManager();
    let count = 0;
    const id = tm.setInterval(() => { count++; }, 30);
    await delay(110);
    tm.clear(id);
    assert(count >= 3, `setInterval викликано ≥3 разів (фактично: ${count})`);
  }

  // --- Test 3: clear зупиняє таймер ---
  console.log('\nTest 3: clear зупиняє таймер');
  {
    const tm = createTimerManager();
    let called = false;
    const id = tm.setTimeout(() => { called = true; }, 100);
    tm.clear(id);
    await delay(150);
    assert(!called, 'таймер не викликано після clear');
  }

  // --- Test 4: clearAll видаляє всі таймери ---
  console.log('\nTest 4: clearAll видаляє всі таймери');
  {
    const tm = createTimerManager();
    let a = false, b = false;
    tm.setTimeout(() => { a = true; }, 100);
    tm.setTimeout(() => { b = true; }, 100);
    tm.clearAll();
    await delay(150);
    assert(!a && !b, 'clearAll зупинив обидва таймери');
  }

  // --- Test 5: pause / resume для setTimeout ---
  console.log('\nTest 5: pause / resume для setTimeout');
  {
    const tm = createTimerManager();
    let called = false;
    tm.setTimeout(() => { called = true; }, 100);
    await delay(30);
    tm.pause();
    await delay(150); // без resume — не має спрацювати
    assert(!called, 'setTimeout не спрацював під час паузи');
    tm.resume();
    await delay(120);
    assert(called, 'setTimeout спрацював після resume');
  }

  // --- Test 6: getActive повертає активні таймери ---
  console.log('\nTest 6: getActive повертає активні таймери');
  {
    const tm = createTimerManager();
    tm.setTimeout(() => {}, 500);
    tm.setInterval(() => {}, 500);
    const active = tm.getActive();
    assert(active.length === 2, `getActive повертає 2 активних таймери (${active.length})`);
    tm.clearAll();
  }

  // --- Підсумок ---
  console.log(`\n📊 Timer Manager: ${passed} passed, ${failed} failed\n`);
}

runTests().catch(console.error);
