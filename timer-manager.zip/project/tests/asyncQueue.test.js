/**
 * Тести для Async Queue
 */

const { createQueue } = require('../src/asyncQueue');

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`  ✅ ${message}`);
    passed++;
  } else {
    console.error(`  ❌ ${message}`);
    failed++;
  }
}

function delay(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

function makeTask(result, ms = 20) {
  return () => delay(ms).then(() => result);
}

async function runTests() {
  console.log('\n📋 Async Queue Tests\n');

  // --- Test 1: базове виконання завдання ---
  console.log('Test 1: базове виконання завдання');
  {
    const q = createQueue();
    const result = await q.add(makeTask('hello'));
    assert(result === 'hello', `завдання виконано і повернуло результат: ${result}`);
  }

  // --- Test 2: concurrency = 1 (послідовне виконання) ---
  console.log('\nTest 2: concurrency = 1 — послідовне виконання');
  {
    const q = createQueue(1);
    const order = [];
    q.add(async () => { await delay(40); order.push(1); });
    q.add(async () => { await delay(10); order.push(2); });
    q.add(async () => { order.push(3); });
    await delay(120);
    assert(JSON.stringify(order) === '[1,2,3]', `порядок: ${JSON.stringify(order)}`);
  }

  // --- Test 3: concurrency = 2 (паралельне виконання) ---
  console.log('\nTest 3: concurrency = 2 — паралельне виконання');
  {
    const q = createQueue(2);
    let maxActive = 0;
    let currentActive = 0;

    const task = () => async () => {
      currentActive++;
      if (currentActive > maxActive) maxActive = currentActive;
      await delay(30);
      currentActive--;
    };

    q.add(task());
    q.add(task());
    q.add(task());
    await delay(200);
    assert(maxActive === 2, `максимум 2 одночасних завдання (було: ${maxActive})`);
  }

  // --- Test 4: статистика ---
  console.log('\nTest 4: статистика');
  {
    const q = createQueue(1);
    q.add(makeTask('a', 30));
    q.add(makeTask('b', 30));
    q.add(makeTask('c', 30));

    await delay(10);
    const s = q.getStats();
    assert(s.active === 1, `active = 1 (є: ${s.active})`);
    assert(s.queued === 2, `queued = 2 (є: ${s.queued})`);

    await delay(150);
    const s2 = q.getStats();
    assert(s2.processed === 3, `processed = 3 (є: ${s2.processed})`);
    assert(s2.queued === 0, `queued = 0 після завершення`);
  }

  // --- Test 5: onDrain ---
  console.log('\nTest 5: onDrain викликається коли черга порожня');
  {
    const q = createQueue(1);
    let drained = false;
    q.onDrain(() => { drained = true; });

    q.add(makeTask('x', 20));
    q.add(makeTask('y', 20));

    await delay(100);
    assert(drained, 'onDrain викликано після завершення всіх завдань');
  }

  // --- Test 6: pause зупиняє нові завдання ---
  console.log('\nTest 6: pause зупиняє нові завдання');
  {
    const q = createQueue(1);
    const order = [];

    q.add(async () => { await delay(20); order.push('A'); });
    q.pause();
    q.add(async () => { order.push('B'); });

    await delay(60);
    assert(order.length === 1 && order[0] === 'A', `під паузою B не виконано (порядок: ${order})`);

    q.resume();
    await delay(40);
    assert(order[1] === 'B', `B виконано після resume`);
  }

  // --- Test 7: обробка помилок ---
  console.log('\nTest 7: помилки не ламають чергу');
  {
    const q = createQueue(1);
    let afterError = false;

    q.add(() => Promise.reject(new Error('fail'))).catch(() => {});
    q.add(async () => { afterError = true; });

    await delay(60);
    assert(afterError, 'наступне завдання виконано після помилки');
  }

  // --- Підсумок ---
  console.log(`\n📊 Async Queue: ${passed} passed, ${failed} failed\n`);
}

runTests().catch(console.error);
