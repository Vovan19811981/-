# js-hof-variant6

**Практична робота 8 — Функції вищого порядку**
**Варіант 6: Event System**

Функціональна система подій, побудована на принципах функціонального програмування: чисті функції, каррінг, композиція, функції вищого порядку.

---

## Структура проекту

```
js-hof-variant6/
├── src/
│   └── eventSystem.js       # Основна реалізація
├── examples/
│   ├── chat.js              # Демо: чат-система
│   └── notifications.js     # Демо: система нотифікацій
├── tests/
│   └── eventSystem.test.js  # Тести
├── package.json
└── README.md
```

---

## Запуск

```bash
# Тести
npm test

# Демо: чат
npm run demo:chat

# Демо: нотифікації
npm run demo:notifications

# Обидва демо
npm run demo
```

---

## Реалізовані функції

### Утиліти функціонального програмування

#### `compose(...fns)`
Композиція функцій справа наліво. `compose(f, g)(x)` → `f(g(x))`

```js
const { compose } = require('./src/eventSystem');

const add1   = x => x + 1;
const double = x => x * 2;

const add1ThenDouble = compose(double, add1);
add1ThenDouble(3); // (3+1)*2 = 8
```

#### `pipe(...fns)`
Композиція функцій зліва направо. `pipe(f, g)(x)` → `g(f(x))`

```js
const { pipe } = require('./src/eventSystem');

const doubleThenAdd1 = pipe(double, add1);
doubleThenAdd1(3); // 3*2+1 = 7
```

#### `curry(fn)`
Перетворює функцію з N аргументами на N функцій з 1 аргументом.

```js
const { curry } = require('./src/eventSystem');

const add = curry((a, b) => a + b);
const add5 = add(5);
add5(3);      // 8
add(2)(3);    // 5
add(2, 3);    // 5 (часткове застосування також працює)
```

---

### Event System API

#### `createEventSystem()`
Створює новий ізольований екземпляр системи подій.

```js
const { createEventSystem } = require('./src/eventSystem');
const es = createEventSystem();
```

---

#### `subscribe(eventName, handler)`
Підписка на подію. Повертає функцію для відписки.

```js
// Підписка
const unsubscribe = es.subscribe('user:login', (eventName, payload) => {
  console.log(`User logged in: ${payload.username}`);
});

// Відписка через повернену функцію
unsubscribe();
```

---

#### `unsubscribe(eventName, handler)`
Видалення конкретного обробника події.

```js
const handler = (name, payload) => console.log(payload);
es.subscribe('event', handler);
es.unsubscribe('event', handler);
```

---

#### `unsubscribeAll(eventName)`
Видалення всіх обробників події.

```js
es.unsubscribeAll('user:login');
```

---

#### `emit(eventName, payload)`
Генерація події. Повертає `eventSystem` для ланцюжків викликів.

```js
es.emit('user:login', { username: 'Alice', role: 'admin' });

// Ланцюжок викликів
es
  .emit('user:join', { username: 'Alice' })
  .emit('message:send', { text: 'Hello!' });
```

---

#### `emitAsync(eventName, payload)`
Асинхронна версія emit. Повертає `Promise`.

```js
const result = await es.emitAsync('data:loaded', { items: [1, 2, 3] });
console.log(result.eventName); // 'data:loaded'
```

---

#### `once(eventName, handler)`
Обробник, що спрацьовує лише один раз, після чого автоматично відписується.

```js
es.once('user:join', (name, payload) => {
  console.log(`Welcome, ${payload.username}! (one-time greeting)`);
});
```

---

#### `addMiddleware(middleware)`
Додає middleware до pipeline. Middleware отримує `(eventName, payload, next)`.
Повертає `eventSystem` для ланцюжків.

```js
// Logging middleware
const logger = (eventName, payload, next) => {
  console.log(`[LOG] ${eventName}`, payload);
  next(eventName, payload); // передати далі
};

// Auth middleware (блокує подію, не викликаючи next)
const authMiddleware = (eventName, payload, next) => {
  if (!payload.token) return; // заблокувати
  next(eventName, payload);
};

es
  .addMiddleware(logger)
  .addMiddleware(authMiddleware);
```

---

#### `onlyIf(predicate, handler)` — HOF + Currying
Обгортає обробник умовою. Викликає handler тільки якщо `predicate(eventName, payload)` повертає `true`.

```js
const isHighPriority = (_, payload) => payload.priority === 'high';

const alertHandler = es.onlyIf(isHighPriority, (name, payload) => {
  console.log('HIGH PRIORITY:', payload.message);
});

es.subscribe('notification', alertHandler);
es.emit('notification', { priority: 'high',  message: 'Urgent!' }); // спрацює
es.emit('notification', { priority: 'low',   message: 'Info'    }); // НЕ спрацює
```

---

#### `onlyEvent(targetEvent, handler)` — Curried HOF
Фільтрує обробник по назві події.

```js
const errorHandler = es.onlyEvent('error', (name, payload) => {
  console.log('ERROR:', payload.message);
});

es.subscribe('error',        errorHandler); // спрацює
es.subscribe('notification', errorHandler); // НЕ спрацює для 'notification'
```

---

#### `composeHandlers(...handlers)` — Композиція обробників
Об'єднує кілька обробників в один. Всі отримують однаковий `(eventName, payload)`.

```js
const displayMessage  = (_, p) => console.log(`Message: ${p.text}`);
const logTimestamp    = (_, p) => console.log(`Time: ${p.timestamp}`);
const updateCounter   = (_, p) => counter++;

const combinedHandler = es.composeHandlers(displayMessage, logTimestamp, updateCounter);
es.subscribe('message', combinedHandler);
```

---

#### `withTransform(transformFn, handler)` — HOF
Трансформує payload перед передачею обробнику.

```js
const sanitize    = p => ({ ...p, text: p.text.replace(/<[^>]*>/g, '') });
const capitalize  = p => ({ ...p, text: p.text[0].toUpperCase() + p.text.slice(1) });
const processText = pipe(sanitize, capitalize);

const safeHandler = es.withTransform(processText, displayMessage);
es.subscribe('message', safeHandler);
```

---

#### `withLogging(logger, handler)` — HOF
Обгортає обробник логуванням.

```js
const loggedHandler = es.withLogging(console.log, myHandler);
es.subscribe('event', loggedHandler);
// Виведе: [EVENT] eventName { ...payload }
// Потім викличе myHandler
```

---

#### `getListeners(eventName)`
Повертає масив обробників для події (копію).

```js
const handlers = es.getListeners('user:login');
console.log(handlers.length); // кількість підписників
```

---

#### `getEventNames()`
Повертає всі зареєстровані назви подій.

```js
es.subscribe('login',   () => {});
es.subscribe('logout',  () => {});
es.getEventNames(); // ['login', 'logout']
```

---

#### `hasListeners(eventName)`
Перевіряє чи є підписники на подію.

```js
es.hasListeners('user:login'); // true / false
```

---

## Приклади

### Чат-система (`examples/chat.js`)
Демонструє:
- Middleware pipeline (logging, timestamp, auth)
- Композицію обробників через `composeHandlers`
- Трансформацію повідомлень через `withTransform` + `pipe`
- `once` для одноразового привітання
- Відписку через повернену функцію
- `emitAsync`

### Система нотифікацій (`examples/notifications.js`)
Демонструє:
- `onlyIf` з curried предикатами
- `onlyEvent` фільтр
- `withLogging` обгортку
- `both` — комбінування предикатів
- Rate limiter через middleware

---

## Принципи функціонального програмування

| Принцип | Реалізація |
|---|---|
| **Чисті функції** | Всі трансформації (`sanitize`, `capitalize`, `processMessage`) не мають побічних ефектів |
| **Імутабельність** | Стан listeners оновлюється через spread: `{ ...listeners, [key]: [...old, new] }` |
| **Каррінг** | `curry`, `onlyIf`, `onlyEvent`, `withTransform`, `withLogging`, `createFilter` |
| **Композиція** | `compose`, `pipe`, `composeHandlers` |
| **HOF** | `onlyIf`, `withTransform`, `withLogging`, `once`, `createFilter` |
| **Замикання** | Внутрішній стан системи прихований через closure |

---

## Demo відео

> 🎥 Посилання на демо відео: https://youtu.be/aLDj0aGWql0?si=cGnl5mOzNmdDY52P

---

## Критерії виконання

| Критерій | Статус |
|---|---|
| Реалізація функцій вищого порядку | ✅ `onlyIf`, `withTransform`, `withLogging`, `once`, `composeHandlers` |
| Чисті функції та імутабельність | ✅ Всі трансформації чисті, стан оновлюється без мутацій |
| Композиція та каррінг | ✅ `compose`, `pipe`, `curry`, `onlyEvent`, `createFilter` |
| subscribe/unsubscribe/emit | ✅ Повна реалізація з поверненням unsub-функції |
| Middleware | ✅ Ланцюжок middleware з можливістю блокування |
| Фільтри | ✅ `onlyIf`, `onlyEvent`, `createFilter` |
| Async | ✅ `emitAsync` повертає Promise |
| Якість коду | ✅ JSDoc, іменовані функції, chainable API |
| README з прикладами | ✅ |
