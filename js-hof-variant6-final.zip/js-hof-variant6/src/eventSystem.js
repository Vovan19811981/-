/**
 * Functional Event System
 * Higher-Order Functions, Currying, Composition
 */

// ============================================================
// PURE UTILITY FUNCTIONS
// ============================================================

/**
 * Compose: right-to-left function composition
 * compose(f, g)(x) => f(g(x))
 */
const compose = (...fns) => x => fns.reduceRight((acc, fn) => fn(acc), x);

/**
 * Pipe: left-to-right function composition
 * pipe(f, g)(x) => g(f(x))
 */
const pipe = (...fns) => x => fns.reduce((acc, fn) => fn(acc), x);

/**
 * Curry: transform a function of N args into N functions of 1 arg
 */
const curry = fn => {
  const arity = fn.length;
  return function curried(...args) {
    if (args.length >= arity) return fn(...args);
    return (...moreArgs) => curried(...args, ...moreArgs);
  };
};

/**
 * Pure identity function
 */
const identity = x => x;

/**
 * Pure always function - returns a function that always returns value
 */
const always = x => () => x;

// ============================================================
// EVENT SYSTEM CORE
// ============================================================

/**
 * createEventSystem - creates a new isolated event system
 * Returns a frozen object with pure-ish functions
 */
const createEventSystem = () => {
  // Internal state (private via closure)
  let listeners = {};
  let middlewares = [];

  // ---- MIDDLEWARE ----

  /**
   * addMiddleware - adds a middleware function to the pipeline
   * Middleware signature: (eventName, payload, next) => void
   */
  const addMiddleware = middleware => {
    middlewares = [...middlewares, middleware];
    return eventSystemAPI; // chainable
  };

  /**
   * runMiddlewares - runs all middlewares in sequence (pure pipeline)
   * @param {string} eventName
   * @param {*} payload
   * @param {Function} finalHandler - called after all middlewares
   */
  const runMiddlewares = (eventName, payload, finalHandler) => {
    const chain = [...middlewares, (name, data, next) => finalHandler(name, data)];

    const execute = index => (name, data) => {
      if (index >= chain.length) return;
      chain[index](name, data, execute(index + 1));
    };

    execute(0)(eventName, payload);
  };

  // ---- FILTERS ----

  /**
   * createFilter - HOF: wraps a handler with a condition filter
   * Only calls handler if filter(eventName, payload) returns true
   */
  const createFilter = curry((filterFn, handler) => (eventName, payload) => {
    if (filterFn(eventName, payload)) {
      handler(eventName, payload);
    }
  });

  /**
   * onlyIf - curried filter: call handler only if predicate is true
   */
  const onlyIf = createFilter;

  /**
   * onlyEvent - filter handler to specific event name
   */
  const onlyEvent = curry((targetEvent, handler) =>
    onlyIf((eventName) => eventName === targetEvent, handler)
  );

  // ---- HANDLER COMPOSITION ----

  /**
   * composeHandlers - combine multiple handlers into one
   * All handlers receive the same (eventName, payload)
   */
  const composeHandlers = (...handlers) => (eventName, payload) =>
    handlers.forEach(handler => handler(eventName, payload));

  /**
   * withTransform - HOF: transform payload before passing to handler
   */
  const withTransform = curry((transformFn, handler) => (eventName, payload) =>
    handler(eventName, transformFn(payload))
  );

  /**
   * withLogging - HOF: wraps handler with console logging
   */
  const withLogging = curry((logger, handler) => (eventName, payload) => {
    logger(`[EVENT] ${eventName}`, payload);
    handler(eventName, payload);
  });

  /**
   * once - HOF: handler that fires only once then auto-unsubscribes
   */
  const once = (eventName, handler) => {
    const wrappedHandler = (evName, payload) => {
      handler(evName, payload);
      unsubscribe(eventName, wrappedHandler);
    };
    subscribe(eventName, wrappedHandler);
    return wrappedHandler;
  };

  // ---- SUBSCRIBE / UNSUBSCRIBE ----

  /**
   * subscribe - register a handler for an event
   * @returns unsubscribe function for this specific handler
   */
  const subscribe = (eventName, handler) => {
    const currentHandlers = listeners[eventName] || [];
    listeners = {
      ...listeners,
      [eventName]: [...currentHandlers, handler]
    };

    // Return unsubscribe function
    return () => unsubscribe(eventName, handler);
  };

  /**
   * unsubscribe - remove a handler from an event
   */
  const unsubscribe = (eventName, handler) => {
    if (!listeners[eventName]) return;
    listeners = {
      ...listeners,
      [eventName]: listeners[eventName].filter(h => h !== handler)
    };
  };

  /**
   * unsubscribeAll - remove all handlers for an event
   */
  const unsubscribeAll = eventName => {
    const { [eventName]: _, ...rest } = listeners;
    listeners = rest;
  };

  // ---- EMIT ----

  /**
   * emit - trigger an event, running all middleware and handlers
   */
  const emit = (eventName, payload) => {
    runMiddlewares(eventName, payload, (name, data) => {
      const handlers = listeners[name] || [];
      handlers.forEach(handler => handler(name, data));
    });
    return eventSystemAPI; // chainable
  };

  /**
   * emitAsync - async version of emit, returns Promise
   */
  const emitAsync = (eventName, payload) =>
    new Promise(resolve => {
      emit(eventName, payload);
      resolve({ eventName, payload });
    });

  // ---- INTROSPECTION ----

  /**
   * getListeners - returns copy of listeners for an event (pure)
   */
  const getListeners = eventName => [...(listeners[eventName] || [])];

  /**
   * getEventNames - returns all registered event names
   */
  const getEventNames = () => Object.keys(listeners);

  /**
   * hasListeners - check if event has any listeners
   */
  const hasListeners = eventName => (listeners[eventName] || []).length > 0;

  // ---- PUBLIC API ----
  const eventSystemAPI = {
    subscribe,
    unsubscribe,
    unsubscribeAll,
    emit,
    emitAsync,
    addMiddleware,
    once,
    onlyIf,
    onlyEvent,
    composeHandlers,
    withTransform,
    withLogging,
    createFilter,
    getListeners,
    getEventNames,
    hasListeners,
  };

  return eventSystemAPI;
};

// ============================================================
// EXPORTED UTILITIES
// ============================================================

module.exports = {
  createEventSystem,
  compose,
  pipe,
  curry,
  identity,
  always,
};
