/**
 * Example: Notification System using Functional Event System
 * Demonstrates: filters, currying, onlyIf, onlyEvent, withLogging
 */

const { createEventSystem, curry } = require('../src/eventSystem');

// ============================================================
// PURE FILTER FUNCTIONS (curried predicates)
// ============================================================

// Only process high-priority notifications
const isHighPriority = (_, payload) => payload.priority === 'high';

// Only process notifications for specific user
const isForUser = curry((userId, _, payload) => payload.userId === userId);

// Only process specific notification types
const isType = curry((type, _, payload) => payload.type === type);

// Combine predicates: both must be true
const both = curry((pred1, pred2) => (name, payload) =>
  pred1(name, payload) && pred2(name, payload)
);

// ============================================================
// NOTIFICATION HANDLERS
// ============================================================

const showBrowserAlert = (_, payload) => {
  console.log(`  🔔 ALERT [${payload.priority?.toUpperCase()}]: ${payload.message}`);
};

const sendEmail = (_, payload) => {
  console.log(`  📧 EMAIL → ${payload.email}: ${payload.message}`);
};

const logToConsole = (_, payload) => {
  console.log(`  📝 LOG: [${payload.type}] ${payload.message}`);
};

const updateBadge = (_, payload) => {
  console.log(`  🔴 BADGE updated for user: ${payload.userId}`);
};

// ============================================================
// NOTIFICATION DEMO
// ============================================================

const runNotificationDemo = () => {
  console.log('\n==============================');
  console.log('   NOTIFICATION SYSTEM DEMO');
  console.log('==============================\n');

  const notifications = createEventSystem();

  // Middleware: rate limiter simulation
  let emitCount = 0;
  const rateLimiter = (eventName, payload, next) => {
    emitCount++;
    if (emitCount > 10) {
      console.log(`  ⚠️  Rate limit reached, dropping event: ${eventName}`);
      return;
    }
    next(eventName, payload);
  };

  notifications.addMiddleware(rateLimiter);

  // --- FILTERED HANDLERS using onlyIf (HOF) ---

  // Only show alert for HIGH priority
  const alertHighPriority = notifications.onlyIf(isHighPriority, showBrowserAlert);

  // Only email notifications for user123
  const emailUser123 = notifications.onlyIf(
    both(isForUser('user123'), isType('account')),
    sendEmail
  );

  // Only log 'system' type notifications
  const logSystemEvents = notifications.onlyIf(isType('system'), logToConsole);

  // With logging wrapper (HOF)
  const loggedBadgeUpdate = notifications.withLogging(
    console.log,
    updateBadge
  );

  // Subscribe
  notifications.subscribe('notification', alertHighPriority);
  notifications.subscribe('notification', emailUser123);
  notifications.subscribe('notification', logSystemEvents);
  notifications.subscribe('notification', loggedBadgeUpdate);

  // --- EMIT ---

  console.log('--- High priority alert ---');
  notifications.emit('notification', {
    type: 'account',
    priority: 'high',
    userId: 'user123',
    email: 'alice@example.com',
    message: 'Your password was changed'
  });

  console.log('\n--- Low priority, wrong user ---');
  notifications.emit('notification', {
    type: 'promo',
    priority: 'low',
    userId: 'user456',
    message: 'Check out our new features!'
  });

  console.log('\n--- System notification ---');
  notifications.emit('notification', {
    type: 'system',
    priority: 'medium',
    userId: 'user123',
    message: 'Server maintenance at 3:00 AM'
  });

  console.log('\n--- onlyEvent filter demo ---');
  const onlyErrors = notifications.onlyEvent('error', (name, payload) => {
    console.log(`  🚨 ERROR HANDLER: ${payload.message}`);
  });
  notifications.subscribe('error', onlyErrors);
  notifications.emit('error', { message: 'Database connection failed' });
  notifications.emit('notification', { message: 'This should NOT trigger error handler' });
};

runNotificationDemo();
