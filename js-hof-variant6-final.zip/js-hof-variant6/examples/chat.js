/**
 * Example: Chat System using Functional Event System
 * Demonstrates: subscribe, emit, middleware, filters, composition
 */

const { createEventSystem, curry, pipe, compose } = require('../src/eventSystem');

// ============================================================
// MIDDLEWARE EXAMPLES
// ============================================================

// Logging middleware - logs every event
const loggingMiddleware = (eventName, payload, next) => {
  console.log(`[LOG] Event: "${eventName}" | Payload:`, payload);
  next(eventName, payload);
};

// Timestamp middleware - adds timestamp to payload
const timestampMiddleware = (eventName, payload, next) => {
  const enriched = typeof payload === 'object'
    ? { ...payload, timestamp: new Date().toISOString() }
    : { data: payload, timestamp: new Date().toISOString() };
  next(eventName, enriched);
};

// Auth middleware - blocks events if user not authorized
const createAuthMiddleware = authorizedUsers => (eventName, payload, next) => {
  if (eventName === 'message:send' && !authorizedUsers.includes(payload.userId)) {
    console.log(`[AUTH] Blocked event "${eventName}" for user: ${payload.userId}`);
    return; // don't call next — blocks the event
  }
  next(eventName, payload);
};

// ============================================================
// PURE TRANSFORM FUNCTIONS
// ============================================================

// Capitalize first letter of message text
const capitalizeMessage = payload => ({
  ...payload,
  text: payload.text
    ? payload.text.charAt(0).toUpperCase() + payload.text.slice(1)
    : payload.text
});

// Sanitize message - remove HTML tags
const sanitizeMessage = payload => ({
  ...payload,
  text: payload.text ? payload.text.replace(/<[^>]*>/g, '') : payload.text
});

// Truncate long messages
const truncateMessage = curry((maxLen, payload) => ({
  ...payload,
  text: payload.text && payload.text.length > maxLen
    ? payload.text.slice(0, maxLen) + '...'
    : payload.text
}));

// Compose transformations: sanitize → capitalize → truncate
const processMessage = pipe(
  sanitizeMessage,
  capitalizeMessage,
  truncateMessage(100)
);

// ============================================================
// CHAT DEMO
// ============================================================

const runChatDemo = () => {
  console.log('\n==============================');
  console.log('   CHAT SYSTEM DEMO');
  console.log('==============================\n');

  const chat = createEventSystem();
  const authorizedUsers = ['user1', 'user2', 'admin'];

  // Add middleware pipeline
  chat
    .addMiddleware(loggingMiddleware)
    .addMiddleware(timestampMiddleware)
    .addMiddleware(createAuthMiddleware(authorizedUsers));

  // --- HANDLERS ---

  // Handler: display message in chat
  const displayMessage = (eventName, payload) => {
    console.log(`  💬 [${payload.userId}]: ${payload.text}`);
  };

  // Handler: notify about new user
  const notifyUserJoined = (eventName, payload) => {
    console.log(`  👤 User joined: ${payload.username}`);
  };

  // Handler: notify user left
  const notifyUserLeft = (eventName, payload) => {
    console.log(`  👋 User left: ${payload.username}`);
  };

  // HOF: handler that transforms payload before displaying
  const displayProcessed = chat.withTransform(processMessage, displayMessage);

  // Compose multiple handlers for message events
  const messageHandlers = chat.composeHandlers(
    displayProcessed,
    (name, payload) => console.log(`  📊 Message length: ${(payload.text || '').length} chars`)
  );

  // Subscribe to events
  const unsubMessage  = chat.subscribe('message:send', messageHandlers);
  const unsubJoin     = chat.subscribe('user:join', notifyUserJoined);
  const unsubLeave    = chat.subscribe('user:leave', notifyUserLeft);

  // one-time welcome message handler
  chat.once('user:join', (name, payload) => {
    console.log(`  🎉 Welcome, ${payload.username}! (once handler)`);
  });

  // --- EMIT EVENTS ---

  console.log('--- Users joining ---');
  chat.emit('user:join', { username: 'Alice', userId: 'user1' });
  chat.emit('user:join', { username: 'Bob',   userId: 'user2' });

  console.log('\n--- Messages ---');
  chat.emit('message:send', { userId: 'user1', text: 'hello everyone!' });
  chat.emit('message:send', { userId: 'user2', text: '<b>hi alice!</b> how are you?' });

  console.log('\n--- Unauthorized user attempt ---');
  chat.emit('message:send', { userId: 'hacker', text: 'malicious message' });

  console.log('\n--- User leaves ---');
  chat.emit('user:leave', { username: 'Bob', userId: 'user2' });

  console.log('\n--- Unsubscribe message handler ---');
  unsubMessage(); // unsubscribe using returned function
  chat.emit('message:send', { userId: 'user1', text: 'this should not display' });
  console.log('  (no message displayed - handler was unsubscribed)');

  console.log('\n--- Async emit ---');
  chat.emitAsync('user:leave', { username: 'Alice', userId: 'user1' })
    .then(result => console.log('  ✅ Async emit resolved:', result.eventName));

  console.log('\n--- Event introspection ---');
  console.log('  Registered events:', chat.getEventNames());
  console.log('  Has "user:join" listeners:', chat.hasListeners('user:join'));
};

runChatDemo();
