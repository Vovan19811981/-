/**
 * Tests for Functional Event System
 * Simple test runner without external dependencies
 */

const { createEventSystem, compose, pipe, curry, identity, always } = require('../src/eventSystem');

// ============================================================
// SIMPLE TEST RUNNER
// ============================================================

let passed = 0;
let failed = 0;

const test = (description, fn) => {
  try {
    fn();
    console.log(`  ✅ ${description}`);
    passed++;
  } catch (e) {
    console.log(`  ❌ ${description}`);
    console.log(`     Error: ${e.message}`);
    failed++;
  }
};

const assert = (condition, message = 'Assertion failed') => {
  if (!condition) throw new Error(message);
};

const assertEqual = (a, b, message) => {
  if (JSON.stringify(a) !== JSON.stringify(b)) {
    throw new Error(message || `Expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);
  }
};

// ============================================================
// UTILITY FUNCTION TESTS
// ============================================================

console.log('\n📦 UTILITY FUNCTIONS');

test('compose: applies functions right-to-left', () => {
  const add1 = x => x + 1;
  const double = x => x * 2;
  const add1ThenDouble = compose(double, add1);
  assertEqual(add1ThenDouble(3), 8); // (3+1)*2 = 8
});

test('pipe: applies functions left-to-right', () => {
  const add1 = x => x + 1;
  const double = x => x * 2;
  const doubleThenAdd1 = pipe(double, add1);
  assertEqual(doubleThenAdd1(3), 7); // 3*2+1 = 7
});

test('curry: transforms multi-arg function', () => {
  const add = curry((a, b) => a + b);
  const add5 = add(5);
  assertEqual(add5(3), 8);
  assertEqual(add(2)(3), 5);
});

test('curry: works with 3 arguments', () => {
  const addThree = curry((a, b, c) => a + b + c);
  assertEqual(addThree(1)(2)(3), 6);
  assertEqual(addThree(1, 2)(3), 6);
  assertEqual(addThree(1)(2, 3), 6);
});

test('identity: returns its argument', () => {
  assertEqual(identity(42), 42);
  assertEqual(identity('hello'), 'hello');
});

test('always: returns a function that always returns the same value', () => {
  const alwaysTrue = always(true);
  assertEqual(alwaysTrue(), true);
  assertEqual(alwaysTrue('anything'), true);
});

// ============================================================
// SUBSCRIBE / UNSUBSCRIBE TESTS
// ============================================================

console.log('\n📡 SUBSCRIBE / UNSUBSCRIBE');

test('subscribe: handler called on emit', () => {
  const es = createEventSystem();
  let called = false;
  es.subscribe('test', () => { called = true; });
  es.emit('test', {});
  assert(called, 'Handler should have been called');
});

test('subscribe: handler receives correct eventName and payload', () => {
  const es = createEventSystem();
  let received = {};
  es.subscribe('greet', (name, payload) => { received = { name, payload }; });
  es.emit('greet', { msg: 'hello' });
  assertEqual(received.name, 'greet');
  assertEqual(received.payload.msg, 'hello');
});

test('subscribe: multiple handlers all called', () => {
  const es = createEventSystem();
  let count = 0;
  es.subscribe('event', () => count++);
  es.subscribe('event', () => count++);
  es.subscribe('event', () => count++);
  es.emit('event', {});
  assertEqual(count, 3);
});

test('unsubscribe: handler not called after unsubscribe', () => {
  const es = createEventSystem();
  let count = 0;
  const handler = () => count++;
  es.subscribe('event', handler);
  es.emit('event', {});
  es.unsubscribe('event', handler);
  es.emit('event', {});
  assertEqual(count, 1, 'Handler should be called only once');
});

test('subscribe: returns unsubscribe function', () => {
  const es = createEventSystem();
  let count = 0;
  const unsub = es.subscribe('event', () => count++);
  es.emit('event', {});
  unsub();
  es.emit('event', {});
  assertEqual(count, 1);
});

test('unsubscribeAll: removes all handlers for event', () => {
  const es = createEventSystem();
  let count = 0;
  es.subscribe('event', () => count++);
  es.subscribe('event', () => count++);
  es.unsubscribeAll('event');
  es.emit('event', {});
  assertEqual(count, 0);
});

test('emit: does not throw if no listeners', () => {
  const es = createEventSystem();
  es.emit('nonexistent', { data: 'test' }); // should not throw
  assert(true);
});

// ============================================================
// ONCE TESTS
// ============================================================

console.log('\n🔂 ONCE');

test('once: handler fires only one time', () => {
  const es = createEventSystem();
  let count = 0;
  es.once('event', () => count++);
  es.emit('event', {});
  es.emit('event', {});
  es.emit('event', {});
  assertEqual(count, 1, 'once handler should fire exactly once');
});

// ============================================================
// MIDDLEWARE TESTS
// ============================================================

console.log('\n🔧 MIDDLEWARE');

test('middleware: called before handlers', () => {
  const es = createEventSystem();
  const order = [];
  es.addMiddleware((name, payload, next) => {
    order.push('middleware');
    next(name, payload);
  });
  es.subscribe('event', () => order.push('handler'));
  es.emit('event', {});
  assertEqual(order, ['middleware', 'handler']);
});

test('middleware: can block events by not calling next', () => {
  const es = createEventSystem();
  let handlerCalled = false;
  es.addMiddleware((name, payload, next) => {
    // intentionally do NOT call next
  });
  es.subscribe('event', () => { handlerCalled = true; });
  es.emit('event', {});
  assert(!handlerCalled, 'Handler should be blocked by middleware');
});

test('middleware: can modify payload', () => {
  const es = createEventSystem();
  let received = null;
  es.addMiddleware((name, payload, next) => {
    next(name, { ...payload, enriched: true });
  });
  es.subscribe('event', (_, payload) => { received = payload; });
  es.emit('event', { original: true });
  assert(received.enriched === true, 'Payload should be enriched by middleware');
  assert(received.original === true, 'Original payload should be preserved');
});

test('middleware: multiple middlewares run in order', () => {
  const es = createEventSystem();
  const order = [];
  es.addMiddleware((n, p, next) => { order.push(1); next(n, p); });
  es.addMiddleware((n, p, next) => { order.push(2); next(n, p); });
  es.addMiddleware((n, p, next) => { order.push(3); next(n, p); });
  es.subscribe('event', () => order.push('handler'));
  es.emit('event', {});
  assertEqual(order, [1, 2, 3, 'handler']);
});

// ============================================================
// FILTERS & HOF TESTS
// ============================================================

console.log('\n🔍 FILTERS & HOF');

test('onlyIf: handler called when condition is true', () => {
  const es = createEventSystem();
  let called = false;
  const handler = es.onlyIf((_, p) => p.value > 5, () => { called = true; });
  es.subscribe('event', handler);
  es.emit('event', { value: 10 });
  assert(called);
});

test('onlyIf: handler NOT called when condition is false', () => {
  const es = createEventSystem();
  let called = false;
  const handler = es.onlyIf((_, p) => p.value > 5, () => { called = true; });
  es.subscribe('event', handler);
  es.emit('event', { value: 3 });
  assert(!called);
});

test('onlyEvent: handler called only for specific event', () => {
  const es = createEventSystem();
  let count = 0;
  const handler = es.onlyEvent('target', () => count++);
  es.subscribe('target', handler);
  es.subscribe('other', handler);
  es.emit('target', {});
  es.emit('other', {});
  assertEqual(count, 1);
});

test('withTransform: transforms payload before handler', () => {
  const es = createEventSystem();
  let received = null;
  const doubleValue = p => ({ ...p, value: p.value * 2 });
  const handler = es.withTransform(doubleValue, (_, p) => { received = p; });
  es.subscribe('event', handler);
  es.emit('event', { value: 5 });
  assertEqual(received.value, 10);
});

test('composeHandlers: all handlers called', () => {
  const es = createEventSystem();
  let a = false, b = false, c = false;
  const combined = es.composeHandlers(
    () => { a = true; },
    () => { b = true; },
    () => { c = true; }
  );
  es.subscribe('event', combined);
  es.emit('event', {});
  assert(a && b && c);
});

// ============================================================
// INTROSPECTION TESTS
// ============================================================

console.log('\n🔎 INTROSPECTION');

test('getListeners: returns correct handlers', () => {
  const es = createEventSystem();
  const h1 = () => {};
  const h2 = () => {};
  es.subscribe('event', h1);
  es.subscribe('event', h2);
  assertEqual(es.getListeners('event').length, 2);
});

test('getEventNames: returns all registered event names', () => {
  const es = createEventSystem();
  es.subscribe('alpha', () => {});
  es.subscribe('beta', () => {});
  es.subscribe('gamma', () => {});
  const names = es.getEventNames();
  assert(names.includes('alpha'));
  assert(names.includes('beta'));
  assert(names.includes('gamma'));
});

test('hasListeners: returns true when listeners exist', () => {
  const es = createEventSystem();
  es.subscribe('event', () => {});
  assert(es.hasListeners('event'));
});

test('hasListeners: returns false when no listeners', () => {
  const es = createEventSystem();
  assert(!es.hasListeners('nonexistent'));
});

// ============================================================
// ASYNC TESTS
// ============================================================

console.log('\n⚡ ASYNC');

test('emitAsync: resolves with eventName and payload', async () => {
  const es = createEventSystem();
  const result = await es.emitAsync('asyncEvent', { data: 42 });
  assertEqual(result.eventName, 'asyncEvent');
  assertEqual(result.payload.data, 42);
});

// ============================================================
// CHAINING TESTS
// ============================================================

console.log('\n🔗 CHAINING');

test('emit: returns eventSystem for chaining', () => {
  const es = createEventSystem();
  const result = es.emit('event', {});
  assert(result === es || typeof result === 'object');
});

test('addMiddleware: returns eventSystem for chaining', () => {
  const es = createEventSystem();
  const result = es.addMiddleware((n, p, next) => next(n, p));
  assert(result !== undefined);
});

// ============================================================
// RESULTS
// ============================================================

console.log('\n==============================');
console.log(`  RESULTS: ${passed} passed, ${failed} failed`);
console.log('==============================\n');

if (failed > 0) process.exit(1);
