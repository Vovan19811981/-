# js-oop-variant6

**Практична робота 11 — Варіант 6: Система управління бібліотекою**

Повна система управління бібліотекою з ієрархією класів, інкапсуляцією та інтерактивним UI.

---

## Структура класів

```
LibraryItem (базовий)
├── Book       — книги (штраф 3 грн/день)
├── Magazine   — журнали (штраф 1 грн/день)
└── DVD        — DVD (штраф 5 грн/день)

Reader         — клас читача
Library        — головний клас управління
```

## ООП принципи

| Принцип | Реалізація |
|---|---|
| **Інкапсуляція** | Приватні поля `#isAvailable`, `#borrowedBy`, `#borrowedAt`, `#reservedBy`, `#totalFines` |
| **Наслідування** | `Book`, `Magazine`, `DVD` extends `LibraryItem` через `extends` + `super()` |
| **Поліморфізм** | `calculateFine()` — різна ставка штрафу для кожного типу |
| **Статичні методи** | `LibraryItem.findByTitle()`, `findByAuthor()`, `findByISBN()` |

---

## Функціонал

- `borrow(reader)` — видача читачу з блокуванням повторної видачі
- `return()` — повернення з автоматичним розрахунком штрафу (14 днів безкоштовно)
- `calculateFine(daysLate)` — поліморфний: Book×3, Magazine×1, DVD×5 грн/день
- `reserve(reader)` — резервування недоступного елементу
- Пошук по назві та автору, фільтрація за типом та доступністю
- Журнал усіх операцій з часовими мітками
- Статистика бібліотеки та штрафи читачів

---

## Запуск

Відкрийте `index.html` у браузері — нічого встановлювати не потрібно.

```
start index.html    # Windows
open index.html     # macOS
```

Для Node.js (тільки логіка, без UI):
```bash
node library.js
```

---

## Структура проєкту

```
js-oop-variant6/
├── index.html    # Інтерактивний UI (каталог, читачі, операції, журнал, статистика)
├── library.js    # Класи з коментарями (для Node.js)
└── README.md
```

---

## Demo відео

> 🎬 **Посилання на demo відео:** https://youtu.be/CKuM2vinzi0?si=WyPUzGrPa7GAj945

---

## Критерії оцінювання

| Критерій | Реалізовано |
|---|---|
| Правильна структура класів з наслідуванням | ✅ `Book/Magazine/DVD extends LibraryItem` |
| Приватні поля та інкапсуляція | ✅ `#isAvailable`, `#borrowedBy`, `#totalFines` тощо |
| Статичні методи та поліморфізм | ✅ `static findByTitle/Author`, поліморфний `calculateFine()` |
| Функціональність відповідає вимогам | ✅ borrow/return/reserve/calculateFine + Library клас |
| UI та demo відео | ✅ |
