/**
 * Практична робота 11 — Варіант 6: Система управління бібліотекою
 * Класи: LibraryItem → Book, Magazine, DVD | Library, Reader
 */

// ─────────────────────────────────────────────
// Базовий клас LibraryItem
// ─────────────────────────────────────────────
class LibraryItem {
  // Приватні поля — інкапсуляція
  #isAvailable;
  #borrowedBy;
  #borrowedAt;
  #reservedBy;

  constructor(title, author, isbn) {
    if (!title || !author || !isbn) {
      throw new Error('Title, author and ISBN are required');
    }
    this.title      = title;
    this.author     = author;
    this.isbn       = isbn;
    this.#isAvailable = true;
    this.#borrowedBy  = null;
    this.#borrowedAt  = null;
    this.#reservedBy  = null;
  }

  // Гетери
  get isAvailable()  { return this.#isAvailable; }
  get borrowedBy()   { return this.#borrowedBy; }
  get borrowedAt()   { return this.#borrowedAt; }
  get reservedBy()   { return this.#reservedBy; }

  /**
   * borrow — видача читачу
   * @param {Reader} reader
   */
  borrow(reader) {
    if (!this.#isAvailable) {
      throw new Error(`"${this.title}" is not available`);
    }
    this.#isAvailable = false;
    this.#borrowedBy  = reader;
    this.#borrowedAt  = new Date();
    this.#reservedBy  = null;
    reader._addItem(this);
    console.log(`📖 "${this.title}" borrowed by ${reader.name}`);
    return this;
  }

  /**
   * return — повернення з розрахунком штрафу
   * @returns {{ fine: number, daysLate: number }}
   */
  return() {
    if (this.#isAvailable) {
      throw new Error(`"${this.title}" is not borrowed`);
    }
    const daysLate = this.#calcDaysLate();
    const fine     = this.calculateFine(daysLate);

    this.#borrowedBy._removeItem(this);
    this.#borrowedBy  = null;
    this.#borrowedAt  = null;
    this.#isAvailable = true;

    console.log(`✅ "${this.title}" returned. Fine: ${fine} UAH`);
    return { fine, daysLate };
  }

  /**
   * calculateFine — розрахунок штрафу (2 UAH/день)
   * @param {number} daysLate
   */
  calculateFine(daysLate) {
    return Math.max(0, daysLate) * 2;
  }

  /**
   * reserve — резервування для читача
   * @param {Reader} reader
   */
  reserve(reader) {
    if (this.#isAvailable) {
      throw new Error(`"${this.title}" is available — just borrow it`);
    }
    if (this.#reservedBy) {
      throw new Error(`"${this.title}" is already reserved`);
    }
    this.#reservedBy = reader;
    console.log(`🔖 "${this.title}" reserved by ${reader.name}`);
    return this;
  }

  // Приватний метод розрахунку днів прострочення
  #calcDaysLate() {
    if (!this.#borrowedAt) return 0;
    const msPerDay   = 1000 * 60 * 60 * 24;
    const daysHeld   = Math.floor((Date.now() - this.#borrowedAt) / msPerDay);
    const allowedDays = 14; // 2 тижні безкоштовно
    return daysHeld - allowedDays;
  }

  // Статичний метод пошуку по масиву
  static findByTitle(items, query) {
    return items.filter(i =>
      i.title.toLowerCase().includes(query.toLowerCase())
    );
  }

  static findByAuthor(items, query) {
    return items.filter(i =>
      i.author.toLowerCase().includes(query.toLowerCase())
    );
  }

  static findByISBN(items, isbn) {
    return items.find(i => i.isbn === isbn) || null;
  }

  // Для відображення типу в UI — перевизначається у нащадках
  get type() { return 'Item'; }

  toJSON() {
    return {
      type:        this.type,
      title:       this.title,
      author:      this.author,
      isbn:        this.isbn,
      isAvailable: this.#isAvailable,
      borrowedBy:  this.#borrowedBy?.name || null,
      reservedBy:  this.#reservedBy?.name || null,
    };
  }
}

// ─────────────────────────────────────────────
// Book extends LibraryItem
// ─────────────────────────────────────────────
class Book extends LibraryItem {
  constructor(title, author, isbn, pages, genre, publisher) {
    super(title, author, isbn);
    this.pages     = pages;
    this.genre     = genre;
    this.publisher = publisher;
  }

  get type() { return 'Book'; }

  // Поліморфізм: книги мають вищий штраф (3 UAH/день)
  calculateFine(daysLate) {
    return Math.max(0, daysLate) * 3;
  }

  toJSON() {
    return { ...super.toJSON(), pages: this.pages, genre: this.genre, publisher: this.publisher };
  }
}

// ─────────────────────────────────────────────
// Magazine extends LibraryItem
// ─────────────────────────────────────────────
class Magazine extends LibraryItem {
  constructor(title, author, isbn, issueNumber, month) {
    super(title, author, isbn);
    this.issueNumber = issueNumber;
    this.month       = month;
  }

  get type() { return 'Magazine'; }

  // Журнали — дешевший штраф (1 UAH/день)
  calculateFine(daysLate) {
    return Math.max(0, daysLate) * 1;
  }

  toJSON() {
    return { ...super.toJSON(), issueNumber: this.issueNumber, month: this.month };
  }
}

// ─────────────────────────────────────────────
// DVD extends LibraryItem
// ─────────────────────────────────────────────
class DVD extends LibraryItem {
  constructor(title, author, isbn, duration, director) {
    super(title, author, isbn);
    this.duration = duration; // хвилини
    this.director = director;
  }

  get type() { return 'DVD'; }

  // DVD — найвищий штраф (5 UAH/день)
  calculateFine(daysLate) {
    return Math.max(0, daysLate) * 5;
  }

  toJSON() {
    return { ...super.toJSON(), duration: this.duration, director: this.director };
  }
}

// ─────────────────────────────────────────────
// Reader — клас читача
// ─────────────────────────────────────────────
class Reader {
  #borrowedItems;
  #totalFines;

  constructor(name, email) {
    if (!name || !email) throw new Error('Name and email are required');
    this.id           = Reader.#nextId++;
    this.name         = name;
    this.email        = email;
    this.#borrowedItems = [];
    this.#totalFines    = 0;
    this.registeredAt   = new Date();
  }

  static #nextId = 1;

  get borrowedItems()  { return [...this.#borrowedItems]; }
  get totalFines()     { return this.#totalFines; }
  get borrowedCount()  { return this.#borrowedItems.length; }

  // Внутрішні методи — викликаються з LibraryItem
  _addItem(item)    { this.#borrowedItems.push(item); }
  _removeItem(item) {
    this.#borrowedItems = this.#borrowedItems.filter(i => i !== item);
  }

  addFine(amount) { this.#totalFines += amount; }

  toJSON() {
    return {
      id:           this.id,
      name:         this.name,
      email:        this.email,
      borrowedCount: this.borrowedCount,
      totalFines:   this.#totalFines,
    };
  }
}

// ─────────────────────────────────────────────
// Library — головний клас управління
// ─────────────────────────────────────────────
class Library {
  #catalog;
  #readers;
  #transactions;

  constructor(name) {
    this.name        = name;
    this.#catalog      = [];
    this.#readers      = [];
    this.#transactions = [];
  }

  // ── Каталог ──
  addItem(item) {
    if (!(item instanceof LibraryItem)) {
      throw new Error('Only LibraryItem instances allowed');
    }
    if (this.#catalog.find(i => i.isbn === item.isbn)) {
      throw new Error(`Item with ISBN ${item.isbn} already exists`);
    }
    this.#catalog.push(item);
    return this;
  }

  removeItem(isbn) {
    const idx = this.#catalog.findIndex(i => i.isbn === isbn);
    if (idx === -1) throw new Error('Item not found');
    this.#catalog.splice(idx, 1);
    return this;
  }

  // ── Читачі ──
  registerReader(reader) {
    if (this.#readers.find(r => r.email === reader.email)) {
      throw new Error('Reader with this email already registered');
    }
    this.#readers.push(reader);
    return this;
  }

  // ── Видача ──
  borrowItem(isbn, readerId) {
    const item   = this.#findItemOrThrow(isbn);
    const reader = this.#findReaderOrThrow(readerId);

    item.borrow(reader);
    this.#logTransaction('borrow', item, reader);
    return item;
  }

  // ── Повернення ──
  returnItem(isbn, readerId) {
    const item   = this.#findItemOrThrow(isbn);
    const reader = this.#findReaderOrThrow(readerId);

    const { fine, daysLate } = item.return();
    if (fine > 0) reader.addFine(fine);

    this.#logTransaction('return', item, reader, { fine, daysLate });
    return { fine, daysLate };
  }

  // ── Резервування ──
  reserveItem(isbn, readerId) {
    const item   = this.#findItemOrThrow(isbn);
    const reader = this.#findReaderOrThrow(readerId);
    item.reserve(reader);
    this.#logTransaction('reserve', item, reader);
    return item;
  }

  // ── Пошук та фільтрація ──
  search(query) {
    return LibraryItem.findByTitle(this.#catalog, query)
      .concat(LibraryItem.findByAuthor(this.#catalog, query))
      .filter((item, idx, arr) => arr.indexOf(item) === idx); // дедуплікація
  }

  filterByType(type) {
    const map = { Book, Magazine, DVD };
    const Cls = map[type];
    return Cls ? this.#catalog.filter(i => i instanceof Cls) : this.#catalog;
  }

  filterByAvailability(available) {
    return this.#catalog.filter(i => i.isAvailable === available);
  }

  // ── Статистика ──
  getStats() {
    const total     = this.#catalog.length;
    const available = this.#catalog.filter(i => i.isAvailable).length;
    const borrowed  = total - available;
    const readers   = this.#readers.length;
    const fines     = this.#readers.reduce((s, r) => s + r.totalFines, 0);

    return { total, available, borrowed, readers, fines };
  }

  get catalog()      { return [...this.#catalog]; }
  get readers()      { return [...this.#readers]; }
  get transactions() { return [...this.#transactions]; }

  // Приватні допоміжні методи
  #findItemOrThrow(isbn) {
    const item = this.#catalog.find(i => i.isbn === isbn);
    if (!item) throw new Error(`Item with ISBN ${isbn} not found`);
    return item;
  }

  #findReaderOrThrow(id) {
    const reader = this.#readers.find(r => r.id === id);
    if (!reader) throw new Error(`Reader #${id} not found`);
    return reader;
  }

  #logTransaction(action, item, reader, extra = {}) {
    this.#transactions.push({
      id:        this.#transactions.length + 1,
      action,
      itemTitle: item.title,
      itemISBN:  item.isbn,
      readerName: reader.name,
      readerId:   reader.id,
      timestamp:  new Date().toLocaleString('uk-UA'),
      ...extra,
    });
  }

  // Статичний метод — порівняння бібліотек за розміром каталогу
  static compare(libA, libB) {
    return libA.catalog.length - libB.catalog.length;
  }
}

// Експорт для Node.js
if (typeof module !== 'undefined') {
  module.exports = { LibraryItem, Book, Magazine, DVD, Reader, Library };
}
