/**
 * Практична робота 10.1 — Варіант 6: Task Scheduler (Promise combinations)
 * Планувальник завдань з різними стратегіями виконання
 */

// ─────────────────────────────────────────────
// Утиліта: затримка
// ─────────────────────────────────────────────
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─────────────────────────────────────────────
// createTask — створює завдання-проміс
// ─────────────────────────────────────────────
/**
 * @param {string} name       — назва завдання
 * @param {number} duration   — тривалість виконання (мс)
 * @param {number} failChance — ймовірність помилки (0..1)
 * @returns {Function} promiseFn — функція, що повертає Promise
 */
function createTask(name, duration, failChance = 0) {
  return function promiseFn() {
    const startedAt = Date.now();
    console.log(`▶ [${name}] started`);

    return delay(duration).then(() => {
      if (Math.random() < failChance) {
        console.error(`✗ [${name}] FAILED after ${duration}ms`);
        throw new Error(`Task "${name}" failed`);
      }
      const elapsed = Date.now() - startedAt;
      console.log(`✔ [${name}] done in ${elapsed}ms`);
      return { name, duration: elapsed, status: 'fulfilled' };
    });
  };
}

// ─────────────────────────────────────────────
// Стратегія 1: Sequential — послідовно
// ─────────────────────────────────────────────
/**
 * Виконує завдання одне за одним.
 * Якщо одне падає — наступні не запускаються.
 * @param {Function[]} tasks
 * @returns {Promise<Object[]>}
 */
function runSequential(tasks) {
  console.log('\n═══ SEQUENTIAL ═══');
  const results = [];
  const start = Date.now();

  // Зводимо масив задач у ланцюжок промісів через reduce
  return tasks
    .reduce((chain, taskFn) => {
      return chain
        .then(() => taskFn())
        .then(result => {
          results.push(result);
        });
    }, Promise.resolve())
    .then(() => {
      const total = Date.now() - start;
      console.log(`Sequential total time: ${total}ms`);
      return { strategy: 'sequential', results, totalTime: total };
    })
    .catch(err => {
      const total = Date.now() - start;
      console.error(`Sequential stopped by error: ${err.message}`);
      return { strategy: 'sequential', results, totalTime: total, error: err.message };
    });
}

// ─────────────────────────────────────────────
// Стратегія 2: Parallel — паралельно (Promise.all)
// ─────────────────────────────────────────────
/**
 * Запускає всі завдання одночасно.
 * Якщо хоча б одне падає — Promise.all відхиляється.
 * @param {Function[]} tasks
 * @returns {Promise<Object>}
 */
function runParallel(tasks) {
  console.log('\n═══ PARALLEL (Promise.all) ═══');
  const start = Date.now();

  return Promise.all(tasks.map(fn => fn()))
    .then(results => {
      const total = Date.now() - start;
      console.log(`Parallel total time: ${total}ms`);
      return { strategy: 'parallel', results, totalTime: total };
    })
    .catch(err => {
      const total = Date.now() - start;
      console.error(`Parallel failed: ${err.message}`);
      return { strategy: 'parallel', results: [], totalTime: total, error: err.message };
    });
}

// ─────────────────────────────────────────────
// Стратегія 3: Race — перший виграє (Promise.race)
// ─────────────────────────────────────────────
/**
 * Повертає результат першого завдання, що завершилось.
 * @param {Function[]} tasks
 * @returns {Promise<Object>}
 */
function runRace(tasks) {
  console.log('\n═══ RACE (Promise.race) ═══');
  const start = Date.now();

  return Promise.race(tasks.map(fn => fn()))
    .then(winner => {
      const total = Date.now() - start;
      console.log(`Race winner: "${winner.name}" in ${total}ms`);
      return { strategy: 'race', winner, totalTime: total };
    })
    .catch(err => {
      const total = Date.now() - start;
      console.error(`Race error: ${err.message}`);
      return { strategy: 'race', totalTime: total, error: err.message };
    });
}

// ─────────────────────────────────────────────
// Стратегія 4: AllSettled — всі результати
// ─────────────────────────────────────────────
/**
 * Запускає всі завдання паралельно, збирає ВСІ результати
 * незалежно від того, чи впали деякі з них.
 * @param {Function[]} tasks
 * @returns {Promise<Object>}
 */
function runAllSettled(tasks) {
  console.log('\n═══ ALL SETTLED (Promise.allSettled) ═══');
  const start = Date.now();

  return Promise.allSettled(tasks.map(fn => fn()))
    .then(outcomes => {
      const total = Date.now() - start;

      const fulfilled = outcomes.filter(o => o.status === 'fulfilled');
      const rejected  = outcomes.filter(o => o.status === 'rejected');

      console.log(`AllSettled: ${fulfilled.length} succeeded, ${rejected.length} failed (${total}ms)`);

      // Формуємо зручний масив результатів
      const results = outcomes.map((o, i) =>
        o.status === 'fulfilled'
          ? o.value
          : { name: `task-${i}`, status: 'rejected', error: o.reason.message }
      );

      return {
        strategy: 'allSettled',
        results,
        totalTime: total,
        stats: { total: tasks.length, succeeded: fulfilled.length, failed: rejected.length }
      };
    });
}

// ─────────────────────────────────────────────
// Demo — порівняння всіх стратегій
// ─────────────────────────────────────────────
function runDemo() {
  // Набір завдань з різними тривалостями та шансами помилки
  const taskDefs = [
    { name: 'Alpha',   duration: 800,  failChance: 0.1 },
    { name: 'Beta',    duration: 1200, failChance: 0.2 },
    { name: 'Gamma',   duration: 600,  failChance: 0.15 },
    { name: 'Delta',   duration: 1000, failChance: 0.1 },
    { name: 'Epsilon', duration: 900,  failChance: 0.05 },
  ];

  // Фабрика: повертає свіжий масив taskFn для кожної стратегії
  const makeTasks = () =>
    taskDefs.map(d => createTask(d.name, d.duration, d.failChance));

  console.log('╔══════════════════════════════════════╗');
  console.log('║      Task Scheduler — Demo Run       ║');
  console.log('╚══════════════════════════════════════╝');

  const summary = {};

  // Запускаємо стратегії послідовно одна за одною (щоб не мішати вивід)
  runSequential(makeTasks())
    .then(res => {
      summary.sequential = res;
      return runParallel(makeTasks());
    })
    .then(res => {
      summary.parallel = res;
      return runRace(makeTasks());
    })
    .then(res => {
      summary.race = res;
      return runAllSettled(makeTasks());
    })
    .then(res => {
      summary.allSettled = res;
    })
    .finally(() => {
      // Фінальна статистика порівняння
      console.log('\n╔══════════════════════════════════════╗');
      console.log('║           COMPARISON SUMMARY         ║');
      console.log('╠══════════════════════════════════════╣');
      Object.values(summary).forEach(s => {
        const timeStr = `${s.totalTime}ms`.padStart(7);
        const errStr  = s.error ? ` ⚠ ${s.error}` : '';
        console.log(`║  ${s.strategy.padEnd(12)} → ${timeStr}${errStr}`);
      });
      console.log('╚══════════════════════════════════════╝');
      console.log('\nDemo complete. Open index.html for interactive UI.');
    });
}

// Запуск demo лише в Node.js
if (typeof window === 'undefined') {
  runDemo();
}

// Експорт для HTML-файлу
if (typeof module !== 'undefined') {
  module.exports = { createTask, runSequential, runParallel, runRace, runAllSettled };
}
