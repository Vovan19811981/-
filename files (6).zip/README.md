# js-arrays-variant3

Практична робота 7 — **Масиви в JavaScript**  
Дисципліна: Основи програмування мовою JavaScript  
**Варіант 3: Task Tracker + Трансформації масивів**

---

## Опис

Веб-застосунок для управління завданнями з реалізацією чотирьох функцій трансформації масивів. Без зовнішніх бібліотек — чистий Vanilla JS ES6+.

## Запуск

Відкрити `index.html` у браузері — сервер не потрібен.

---

## Функціональність

### Task Tracker

- Додавання завдань: заголовок, пріоритет (high / medium / low), дедлайн
- Зміна статусу: `todo` → `in-progress` → `done`
- Видалення завдань
- Фільтрація за пріоритетом та статусом
- Статистика: виконано, у процесі, очікує, прострочені

### Трансформації масивів

```js
// 1. flatten — рекурсивне розгортання вкладеного масиву
const flatten = arr =>
  arr.reduce((acc, val) =>
    Array.isArray(val) ? acc.concat(flatten(val)) : acc.concat(val), []);

// flatten([[1,[2,3]],[4,[5,[6]]]]) → [1,2,3,4,5,6]
```

```js
// 2. groupBy — групування об'єктів за полем
const groupBy = (arr, key) =>
  arr.reduce((acc, item) => {
    const k = item[key];
    if (!acc[k]) acc[k] = [];
    acc[k].push(item);
    return acc;
  }, {});

// groupBy(tasks, 'priority') → { high: [...], medium: [...], low: [...] }
```

```js
// 3. unique — унікальні елементи, зберігаючи порядок
const unique = arr => {
  const seen = new Set();
  return arr.filter(x => !seen.has(x) && seen.add(x));
};

// unique([1,2,2,3,1,4]) → [1,2,3,4]
```

```js
// 4. chunk — розбиття масиву на частини заданого розміру
const chunk = (arr, size) => {
  const res = [];
  for (let i = 0; i < arr.length; i += size)
    res.push(arr.slice(i, i + size));
  return res;
};

// chunk([1,2,3,4,5,6,7], 3) → [[1,2,3],[4,5,6],[7]]
```

---

## Технічні вимоги ✅

- ✅ ES6+: arrow functions, spread, destructuring, `const`/`let`
- ✅ `map`, `filter`, `reduce` використовуються де доречно
- ✅ Валідація вхідних даних (порожня назва, некоректний JSON)
- ✅ Обробка крайніх випадків (порожні масиви, прострочені дати)
- ✅ Без зовнішніх бібліотек
- ✅ HTML-інтерфейс з live-демонстрацією всіх функцій

## Структура

```
js-arrays-variant3/
├── index.html   # весь застосунок (HTML + CSS + JS в одному файлі)
└── README.md
```
